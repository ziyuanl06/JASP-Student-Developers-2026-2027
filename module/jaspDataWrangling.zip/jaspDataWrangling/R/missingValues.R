#
# Copyright (C) 2013-2026 University of Amsterdam
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

# JASP calls this function every time something changes in the window.
#   jaspResults : the box we put our output into
#   dataset     : the data (we don't use it yet. That's Session 3!)
#   options     : everything the user clicked, as a named list
missingValues <- function(jaspResults, dataset, options) {

  # A friendly note, so the window is never empty
  jaspResults[["welcome"]] <- createJaspHtml(
    title = gettext("Under construction"),
    text  = gettext("This analysis doesn't compute anything yet. Below you can see
                     exactly what JASP sends to R. Click something on the left and
                     watch this table change!")
  )

  # Show every option R received
  jaspResults[["optionsSeen"]] <- createJaspHtml(
    title = gettext("What R received (options)"),
    text  = .dwOptionsAsHtml(options)
  )

  return()
}
