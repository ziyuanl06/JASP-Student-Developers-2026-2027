#
# Copyright (C) 2013-2026 University of Amsterdam
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

# A tour of JASP output: text, a table and a plot.
# Every options$<name> below comes from a control in inst/qml/controlPlayground.qml.
controlPlayground <- function(jaspResults, dataset, options) {

  # 1. Text --------------------------------------------------------------
  jaspResults[["hello"]] <- createJaspHtml(
    title = gettext("Hello"),
    text  = sprintf("Hello, <b>%s</b>! &#128075; Change the controls on the left and watch this page update.",
                    .dwEscape(options$yourName))
  )

  # 2. Simulate data from the controls -------------------------------------
  set.seed(as.integer(options$seed))
  x <- stats::rnorm(n = options$sampleSize, mean = options$mean, sd = options$sd)

  # 3. A table ---------------------------------------------------------------
  table <- createJaspTable(title = gettext("Your simulated data"))
  table$dependOn(c("sampleSize", "mean", "sd", "seed"))   # redo only when these change

  table$addColumnInfo(name = "n",      title = gettext("N"),      type = "integer")
  table$addColumnInfo(name = "mean",   title = gettext("Mean"),   type = "number")
  table$addColumnInfo(name = "sd",     title = gettext("SD"),     type = "number")
  table$addColumnInfo(name = "min",    title = gettext("Min"),    type = "number")
  table$addColumnInfo(name = "max",    title = gettext("Max"),    type = "number")

  table$addRows(list(n = length(x), mean = mean(x), sd = stats::sd(x),
                     min = min(x), max = max(x)))
  table$addFootnote(gettext("Asked for: mean and SD from your controls. Got: slightly different. That's sampling!"))

  jaspResults[["table"]] <- table

  # 4. A plot (only if the checkbox is ticked) -------------------------------
  if (options$showPlot) {
    colours <- c(teal = "#55a4a4", orange = "#e98a6b", purple = "#8e7cc3")

    p <- ggplot2::ggplot(data.frame(x = x), ggplot2::aes(x = x)) +
      ggplot2::geom_histogram(bins = 20, fill = colours[[options$barColor]], colour = "white") +
      ggplot2::labs(x = gettext("Value"), y = gettext("Count")) +
      jaspGraphs::themeJaspRaw()

    if (options$showMeanLine)
      p <- p + ggplot2::geom_vline(xintercept = mean(x), linetype = "dashed", linewidth = 1)

    plot <- createJaspPlot(plot = p, title = gettext("Histogram"), width = 480, height = 320)
    plot$dependOn(c("sampleSize", "mean", "sd", "seed", "showPlot", "showMeanLine", "barColor"))
    jaspResults[["plot"]] <- plot
  }

  # 5. Behind the scenes: everything R received ------------------------------
  if (options$showOptions) {
    seen <- createJaspHtml(title = gettext("What R received (options)"),
                           text  = .dwOptionsAsHtml(options))
    seen$dependOn("showOptions")
    jaspResults[["optionsSeen"]] <- seen
  }

  return()
}
