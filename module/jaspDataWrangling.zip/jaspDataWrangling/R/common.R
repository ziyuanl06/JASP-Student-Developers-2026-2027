#
# Copyright (C) 2013-2026 University of Amsterdam
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

# ── Helpers ─────────────────────────────────────────────────────────────
# Functions starting with "." are helpers: JASP never calls them directly.
# They live here so every analysis in this module can use them.

.dwOptionsAsHtml <- function(options) {
  # JASP adds some internal options (names starting with "."); hide them
  keep <- !startsWith(names(options), ".")
  options <- options[keep]

  if (length(options) == 0)
    return(gettext("No options yet. Add a control to the QML file!"))

  rows <- vapply(names(options), function(name) {
    sprintf("<tr><td><code>options$%s</code></td><td><code>%s</code></td></tr>",
            .dwEscape(name), .dwEscape(.dwShowValue(options[[name]])))
  }, character(1))

  paste0("<table><tr><th>Name</th><th>Value</th></tr>",
         paste(rows, collapse = ""), "</table>")
}

.dwShowValue <- function(value) {
  value <- unlist(value)
  if (length(value) == 0 || identical(value, ""))
    return("(empty)")
  if (is.character(value))
    value <- paste0('"', value, '"')
  if (length(value) > 1)
    return(paste0("c(", paste(value, collapse = ", "), ")"))
  as.character(value)
}

.dwEscape <- function(x) {
  x <- gsub("&", "&amp;", x, fixed = TRUE)
  x <- gsub("<", "&lt;",  x, fixed = TRUE)
  gsub(">", "&gt;", x, fixed = TRUE)
}
