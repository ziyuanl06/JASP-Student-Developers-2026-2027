//
// Copyright (C) 2013-2026 University of Amsterdam
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as
// published by the Free Software Foundation, either version 3 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public
// License along with this program.  If not, see
// <http://www.gnu.org/licenses/>.
//
import QtQuick
import QtQuick.Layouts
import JASP.Controls
import JASP.Widgets
import JASP

Form
{
	info: qsTr("Find out where your data has holes. (Under construction by the JASP Student Developers Group.)")

	// ── Pick variables ──────────────────────────────────────────────────
	// Every control has a "name". That name becomes options$<name> in R.
	VariablesForm
	{
		AvailableVariablesList { name: "allVariables" }
		AssignedVariablesList
		{
			name			: "variables"                          // → options$variables
			title			: qsTr("Variables")
			allowedColumns	: ["scale", "ordinal", "nominal"]      // any column type
		}
	}
}
