//
// Copyright (C) 2013-2026 University of Amsterdam
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as
// published by the Free Software Foundation, either version 3 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public
// License along with this program.  If not, see
// <http://www.gnu.org/licenses/>.
//
import QtQuick
import QtQuick.Layouts
import JASP.Controls
import JASP.Widgets
import JASP

// A tour of JASP controls. Every control has a "name": that name becomes
// options$<name> in R/controlPlayground.R. Change something here, then
// Build → Install in RStudio and refresh JASP to see what happens.
Form
{
	info: qsTr("A playground for JASP controls: simulate some data, then poke every control and watch the output change.")

	// ── Text ───────────────────────────────────────────────────────────
	TextField
	{
		name			: "yourName"                     // → options$yourName  ("JASP")
		label			: qsTr("Your name")
		defaultValue	: "JASP"
		fieldWidth		: 160
	}

	// ── Numbers ────────────────────────────────────────────────────────
	Group
	{
		title: qsTr("Simulate data")

		IntegerField                                    // whole numbers only
		{
			name			: "sampleSize"               // → options$sampleSize  (100)
			label			: qsTr("Sample size")
			defaultValue	: 100
			min				: 2
			max				: 10000
		}

		DoubleField                                     // numbers with decimals
		{
			name			: "mean"                     // → options$mean  (0)
			label			: qsTr("Mean")
			defaultValue	: 0
			negativeValues	: true
		}

		Slider                                          // drag to choose
		{
			name			: "sd"                       // → options$sd  (1)
			label			: qsTr("Standard deviation")
			value			: 1
			min				: 0.1
			max				: 5
			decimals		: 1
		}

		DropDown                                        // pick one from a list
		{
			name			: "seed"                     // → options$seed  ("42")
			label			: qsTr("Random seed")
			values			: ["42", "2026", "123"]
		}
	}

	// ── On / off and choices ──────────────────────────────────────────
	Group
	{
		title: qsTr("Plot")

		CheckBox                                        // TRUE / FALSE
		{
			name	: "showPlot"                         // → options$showPlot  (TRUE)
			label	: qsTr("Show histogram")
			checked	: true

			// A control nested inside a CheckBox is only active when it's ticked
			CheckBox { name: "showMeanLine"; label: qsTr("Mark the mean") }   // → options$showMeanLine
		}

		RadioButtonGroup                                // exactly one of several
		{
			name	: "barColor"                         // → options$barColor  ("teal")
			title	: qsTr("Bar colour")
			RadioButton { value: "teal";   label: qsTr("Teal");   checked: true }
			RadioButton { value: "orange"; label: qsTr("Orange") }
			RadioButton { value: "purple"; label: qsTr("Purple") }
		}
	}

	// ── A collapsible section ─────────────────────────────────────────
	Section
	{
		title: qsTr("Behind the scenes")

		CheckBox
		{
			name	: "showOptions"                      // → options$showOptions  (TRUE)
			label	: qsTr("Show what R received")
			checked	: true
		}
	}
}
