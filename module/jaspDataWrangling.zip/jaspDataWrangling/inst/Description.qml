import QtQuick
import JASP.Module

Description
{
	name		: "jaspDataWrangling"          // must match "Package:" in DESCRIPTION
	title		: qsTr("Data Wrangling")       // the name on JASP's ribbon
	description	: qsTr("Diagnose and fix messy data. Built by the JASP Student Developers Group.")
	version		: "0.0.1"
	author		: "JASP Student Developers Group"
	maintainer	: "Leo Liu <ziyuanl06@gmail.com>"
	website		: "https://ziyuanl06.github.io/JASP-Student-Developers-2026-2027/"
	license		: "GPL (>= 2)"
	icon		: "exampleIcon.png"            // lives in inst/icons/
	preloadData	: true
	requiresData: false

	GroupTitle
	{
		title: qsTr("Playground")
	}

	Analysis
	{
		title		: qsTr("Control Playground")
		menu		: qsTr("Control Playground")
		func		: "controlPlayground"
		qml			: "controlPlayground.qml"
		requiresData: false
	}

	GroupTitle
	{
		title: qsTr("Diagnose")
	}

	Analysis
	{
		title		: qsTr("Missing Values")   // title of the analysis window
		menu		: qsTr("Missing Values")   // what users see in the menu
		func		: "missingValues"          // the R function to call (R/missingValues.R)
		qml			: "missingValues.qml"      // the window (inst/qml/missingValues.qml)
		requiresData: false                    // runs even without a dataset (for now!)
	}

	// Later sessions add more Analysis { } blocks here.
	// Copy the block above, then change title, menu, func and qml.
}
