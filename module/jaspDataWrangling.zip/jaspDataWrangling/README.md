# jaspDataWrangling

A JASP module built step by step by the **JASP Student Developers Group (2026–27)**.
It starts as one empty analysis window. Session by session, it grows into tools that
**diagnose** and **fix** messy data.

Course site: <https://ziyuanl06.github.io/JASP-Student-Developers-2026-2027/>

## What's inside

```
jaspDataWrangling/
├── DESCRIPTION                ← R package info (name, dependencies)
├── NAMESPACE                  ← which R functions JASP may call
├── R/
│   ├── controlPlayground.R    ← tour of outputs: text, table, plot
│   ├── missingValues.R        ← the computation (R)
│   └── common.R               ← small helpers shared by all analyses
├── inst/
│   ├── Description.qml        ← adds the module to JASP's menu
│   ├── icons/                 ← the ribbon icon
│   └── qml/
│       ├── controlPlayground.qml ← tour of controls: fields, slider, dropdown, ...
│       └── missingValues.qml  ← the analysis window (buttons, checkboxes, ...)
├── renv.lock, renv/, .Rprofile ← pins package versions (don't edit by hand)
└── jaspDataWrangling.Rproj    ← open THIS in RStudio
```

## First-time setup

1. Install **JASP nightly** (development branch) and **R + RStudio**.
2. Double-click `jaspDataWrangling.Rproj`. RStudio opens and renv starts automatically.
3. In the RStudio console:

   ```r
   renv::install(".")
   ```

   This installs jaspBase, jaspGraphs and their dependencies. It takes a while the first time.
4. In RStudio, run `.libPaths()` and copy the first path.
   In JASP: ☰ Menu → Preferences → Advanced → **Development module**:
   tick **Enable renv mode**, paste the path into **Project library**,
   set **Module name** to `jaspDataWrangling`, then **Install Developer Module**.
5. A **Data Wrangling** button appears on the ribbon. Start with *Control Playground*.

## The edit loop

```
Save .qml / .R  →  RStudio: Build → Install  →  JASP: refresh / Install Developer Module  ↺
```

## Adding a new analysis

1. Add an `Analysis { }` block to `inst/Description.qml` (title, menu, func, qml).
2. Create `inst/qml/<name>.qml`.
3. Create `R/<name>.R` with `<name> <- function(jaspResults, dataset, options) { ... }`.
4. Add `export(<name>)` to `NAMESPACE`.

Forgetting step 4 is the most common reason for "could not find function".

## License

GPL (>= 2). Based on [jasp-stats/jaspModuleTemplate](https://github.com/jasp-stats/jaspModuleTemplate).
